


---------------------------------------------------------------------------------------------------------------------------------------

Select the option to import custom rules and see if the program in the rule directly violates the rule.

(note: by default, the imported rule is off, and the program violation option is interrogation)

To ensure that the switch of custom rule function is on, view method: tinder safety home page > protection center > advanced protection > custom protection.

Turning on tinder password protection is strictly required because the rule is meant to prevent people, not programs.

It is recommended to turn on access control for USB flash drives and disable access to external USB flash drives to ensure tinder is not killed by other driver tools and security software.

This rule is for others to use. If you use it yourself, please turn it off.

If there are any problems during the use, please feedback your opinions to the rule post below.

In addition, the rules package download instructions and rules package have two different languages, so you only need to import one.

---------------------------------------------------------------------------------------------------------------------------------------

You can also contact QQ:3302374603 for feedback.

						

						Finally, thanks for tinder BBS FLY_MC's help.